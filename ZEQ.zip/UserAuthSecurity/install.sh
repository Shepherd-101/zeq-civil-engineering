#!/bin/bash

# ZEQ Civil Engineering Project Management System
# Installation Script for Linux/macOS

set -e

echo "🏗️  Installing ZEQ Civil Engineering Project Management System..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.7+ and try again."
    exit 1
fi

# Check Python version
python_version=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
required_version="3.7"

if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" != "$required_version" ]; then
    echo "❌ Python $python_version is installed, but ZEQ requires Python $required_version or higher."
    exit 1
fi

echo "✅ Python $python_version detected"

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed. Please install pip and try again."
    exit 1
fi

echo "✅ pip3 detected"

# Create virtual environment (optional but recommended)
read -p "🔧 Create virtual environment? (recommended) [y/N]: " create_venv
if [[ $create_venv =~ ^[Yy]$ ]]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv zeq_env
    source zeq_env/bin/activate
    echo "✅ Virtual environment created and activated"
fi

# Install dependencies
echo "📦 Installing dependencies..."
pip3 install fastapi sqlalchemy passlib[bcrypt] python-multipart uvicorn psycopg2-binary

echo "✅ Dependencies installed successfully"

# Create uploads directory
echo "📁 Creating uploads directory..."
mkdir -p uploads
touch uploads/.gitkeep

echo "✅ Directory structure created"

# Set executable permissions
chmod +x install.sh

echo ""
echo "🎉 ZEQ installation completed successfully!"
echo ""
echo "📋 Next steps:"
echo "1. Start the server: uvicorn main:app --host 0.0.0.0 --port 8000"
echo "2. Access the API: http://localhost:8000"
echo "3. View documentation: http://localhost:8000/docs"
echo "4. Create your first admin user via the API"
echo ""
echo "📚 For detailed instructions, see README.md and DEPLOYMENT.md"
echo ""

# Optional: Start the server
read -p "🚀 Start the ZEQ server now? [y/N]: " start_server
if [[ $start_server =~ ^[Yy]$ ]]; then
    echo "🚀 Starting ZEQ server..."
    echo "🌐 Access your ZEQ system at: http://localhost:8000"
    echo "📖 API Documentation: http://localhost:8000/docs"
    echo "🔧 Health Check: http://localhost:8000/health"
    echo ""
    echo "Press Ctrl+C to stop the server"
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload
fi