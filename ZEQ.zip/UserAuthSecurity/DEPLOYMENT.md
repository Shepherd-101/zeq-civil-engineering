# ZEQ Deployment Guide

This guide provides detailed instructions for deploying ZEQ in different environments.

## Quick Start (Local Development)

1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/zeq-civil-engineering.git
   cd zeq-civil-engineering
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   # or
   pip install .
   ```

3. **Run the application:**
   ```bash
   uvicorn main:app --host 0.0.0.0 --port 8000 --reload
   ```

4. **Access the application:**
   - API: http://localhost:8000
   - Documentation: http://localhost:8000/docs

## Production Deployment

### Option 1: Traditional Server

1. **Set up environment variables:**
   ```bash
   export DATABASE_URL="postgresql://user:password@localhost/zeq_db"
   export CORS_ORIGINS="https://yourdomain.com"
   ```

2. **Install dependencies:**
   ```bash
   pip install .
   ```

3. **Run with production server:**
   ```bash
   gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
   ```

### Option 2: Docker (Coming Soon)

Docker support will be added in future versions.

## Database Configuration

### SQLite (Default)
- No additional setup required
- Database file created automatically
- Perfect for small teams (1-10 users)

### PostgreSQL (Recommended for Production)
1. **Install PostgreSQL**
2. **Create database:**
   ```sql
   CREATE DATABASE zeq_db;
   CREATE USER zeq_user WITH PASSWORD 'your_password';
   GRANT ALL PRIVILEGES ON DATABASE zeq_db TO zeq_user;
   ```
3. **Set environment variable:**
   ```bash
   export DATABASE_URL="postgresql://zeq_user:your_password@localhost/zeq_db"
   ```

## Security Configuration

### Production Security Checklist

1. **Update CORS settings** in `main.py`:
   ```python
   app.add_middleware(
       CORSMiddleware,
       allow_origins=["https://yourdomain.com"],  # Restrict to your domain
       allow_credentials=True,
       allow_methods=["GET", "POST", "PUT", "DELETE"],
       allow_headers=["*"],
   )
   ```

2. **Set up HTTPS** with reverse proxy (nginx/Apache)

3. **Configure firewall** to restrict access

4. **Set up regular backups** for database and uploaded files

## Network Access

### Local Network Access
- Run on `0.0.0.0` to allow network access
- Users can access via `http://YOUR_SERVER_IP:8000`

### Internet Access
- Set up reverse proxy (nginx recommended)
- Configure SSL certificate
- Set up domain name

## File Storage

### Default (Local Storage)
- Files stored in `uploads/` directory
- Organized by project ID
- Ensure proper permissions and backup

### Future: Cloud Storage
- S3/Azure Blob support planned
- Configuration via environment variables

## Initial Setup

1. **Create admin user:**
   ```bash
   curl -X POST "http://localhost:8000/register" \
        -H "Content-Type: application/json" \
        -d '{"username": "admin", "password": "secure_password", "role": "admin"}'
   ```

2. **Login to get token:**
   ```bash
   curl -X POST "http://localhost:8000/token" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "username=admin&password=secure_password"
   ```

3. **Create first project via API documentation at `/docs`**

## Monitoring and Maintenance

### Health Check
- Endpoint: `/health`
- Returns system status and timestamp

### Logs
- Application logs via uvicorn
- Database logs via PostgreSQL
- File upload logs in application

### Backup Strategy
1. **Database backup** (daily recommended)
2. **File backup** (uploaded documents)
3. **Configuration backup** (environment variables)

## Troubleshooting

### Common Issues

1. **Port already in use:**
   ```bash
   # Find and kill process
   lsof -i :8000
   kill -9 <PID>
   ```

2. **Database connection errors:**
   - Check DATABASE_URL format
   - Verify PostgreSQL is running
   - Check user permissions

3. **File upload errors:**
   - Check `uploads/` directory permissions
   - Verify disk space
   - Check file size limits

### Support
- Check API documentation at `/docs`
- Review application logs
- Verify database connections

## Performance Optimization

### For Small Teams (1-10 users)
- SQLite database
- Single uvicorn worker
- Local file storage

### For Medium Teams (10-50 users)
- PostgreSQL database
- Multiple workers with gunicorn
- Regular database maintenance

### For Large Teams (50+ users)
- PostgreSQL with connection pooling
- Load balancer with multiple instances
- Cloud file storage
- Database optimization and indexing