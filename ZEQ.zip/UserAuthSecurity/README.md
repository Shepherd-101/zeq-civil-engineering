# ZEQ - Civil Engineering Project Management System

A complete civil engineering project management system with FastAPI backend, designed for local deployment and in-house use.

## Features

- **User Authentication**: Role-based access control (admin, pm, inspector, contractor)
- **Project Management**: Create, view, and manage civil engineering projects
- **File Management**: Upload/download CAD files (.dwg), PDFs, images, and other engineering documents
- **Field Notes**: Add and track project documentation and field observations
- **Digital Signatures**: Capture and store digital signatures for approvals
- **Timesheet Tracking**: Track hours worked on projects with detailed descriptions
- **RESTful API**: Complete API for all functionality with proper error handling

## Technology Stack

- **Backend**: FastAPI (Python)
- **Database**: SQLite (local file-based)
- **ORM**: SQLAlchemy
- **Authentication**: Token-based with bcrypt password hashing
- **File Storage**: Local filesystem with organized project folders

## Installation & Setup

### Quick Installation

**Option 1: Automated Installation (Recommended)**
```bash
# Linux/macOS
git clone https://github.com/yourusername/zeq-civil-engineering.git
cd zeq-civil-engineering
chmod +x install.sh
./install.sh

# Windows
git clone https://github.com/yourusername/zeq-civil-engineering.git
cd zeq-civil-engineering
install.bat
```

**Option 2: Manual Installation**
### Prerequisites
- Python 3.7+
- pip

1. **Clone the repository:**
```bash
git clone https://github.com/yourusername/zeq-civil-engineering.git
cd zeq-civil-engineering
```

2. **Install dependencies:**
```bash
pip install fastapi sqlalchemy passlib[bcrypt] python-multipart uvicorn psycopg2-binary
```

3. **Set up your database:**
   - For SQLite (default): No additional setup required
   - For PostgreSQL: Set the `DATABASE_URL` environment variable
   ```bash
   export DATABASE_URL="postgresql://user:password@localhost/zeq_db"
   ```

4. **Run the application:**
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

5. **Access the application:**
   - API Documentation: http://localhost:8000/docs
   - Health Check: http://localhost:8000/health
   - API Root: http://localhost:8000/

## API Usage

### Authentication
1. Register a new user:
   ```bash
   curl -X POST "http://localhost:8000/register" \
        -H "Content-Type: application/json" \
        -d '{"username": "admin", "password": "password", "role": "admin"}'
   ```

2. Login to get access token:
   ```bash
   curl -X POST "http://localhost:8000/token" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "username=admin&password=password"
   ```

### Project Management
- Create projects, upload files, add notes, signatures, and timesheets
- All endpoints require authentication (Bearer token)
- Role-based access control ensures proper permissions

## Database Configuration

The application supports both SQLite and PostgreSQL:

- **SQLite** (default): Local file-based database, perfect for small teams
- **PostgreSQL**: Set `DATABASE_URL` environment variable for production use

## File Storage

Uploaded files are stored in the `uploads/` directory, organized by project ID. Supported file types include:
- CAD files (.dwg)
- PDF documents
- Images (.jpg, .jpeg, .png, .tiff, .bmp, .gif, .svg)

## User Roles

- **admin**: Full access to all projects and users
- **pm**: Project manager with extended permissions
- **inspector**: Field inspection capabilities
- **contractor**: Basic project access

## Development

For development with auto-reload:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
