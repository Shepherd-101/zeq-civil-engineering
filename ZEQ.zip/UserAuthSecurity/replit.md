# ZEQ - Civil Engineering Project Management System

## Overview

ZEQ is a comprehensive civil engineering project management system built with FastAPI. It's designed for local deployment and in-house use, providing essential project management capabilities including user authentication, file management, field notes, digital signatures, and timesheet tracking.

**Status**: Complete and ready for deployment
**Last Updated**: July 11, 2025

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: FastAPI (Python) - chosen for its modern async capabilities, automatic API documentation, and excellent performance
- **API Design**: RESTful architecture with proper HTTP status codes and error handling
- **Authentication**: Token-based authentication using OAuth2 with bcrypt password hashing
- **Middleware**: CORS middleware configured for cross-origin requests (currently permissive for development)

### Database Architecture
- **Database**: SQLite - lightweight, file-based database perfect for local deployment and small to medium teams
- **ORM**: SQLAlchemy - provides database abstraction and relationship management
- **Schema Design**: Relational model with proper foreign key relationships between users, projects, files, and related entities

### File Storage Strategy
- **Storage**: Local filesystem with organized project folder structure
- **File Types**: Supports CAD files (.dwg), PDFs, images, and other engineering documents
- **Organization**: Files organized by project for easy access and management

## Key Components

### User Management System
- **Role-based Access Control**: Four user roles (admin, pm, inspector, contractor)
- **Authentication**: Secure password hashing with bcrypt
- **Authorization**: Token-based system for API access control

### Project Management Core
- **Project CRUD**: Complete create, read, update, delete operations for projects
- **Project Association**: Links users, files, notes, and timesheets to specific projects
- **Project Organization**: Structured approach to managing multiple engineering projects

### File Management System
- **Upload/Download**: Handles file operations for engineering documents
- **File Types**: Specialized support for engineering file formats
- **Storage Organization**: Project-based file organization for easy retrieval

### Documentation System
- **Field Notes**: Capture and track project observations and documentation
- **Digital Signatures**: Store approval signatures for project milestones
- **Timesheet Tracking**: Detailed hour tracking with project associations

## Data Flow

1. **Authentication Flow**: Users authenticate via OAuth2, receive tokens for API access
2. **Project Flow**: Authenticated users can create/manage projects based on their role
3. **File Flow**: Files are uploaded to project-specific directories, metadata stored in database
4. **Documentation Flow**: Notes, signatures, and timesheets are linked to projects and users
5. **API Flow**: All operations go through FastAPI endpoints with proper validation and error handling

## External Dependencies

### Core Framework Dependencies
- **FastAPI**: Main web framework for API development
- **SQLAlchemy**: Object-relational mapping for database operations
- **Passlib[bcrypt]**: Password hashing and verification
- **Python-multipart**: File upload handling
- **Uvicorn**: ASGI server for running the FastAPI application

### Development Dependencies
- **Python 3.7+**: Minimum Python version requirement
- **pip**: Package management for Python dependencies

## Deployment Strategy

### Local Deployment Focus
- **Target Environment**: Designed for in-house, local network deployment
- **Database**: SQLite file-based database (no separate database server required)
- **File Storage**: Local filesystem (no cloud storage dependencies)
- **Configuration**: Environment variable support for production settings

### Security Considerations
- **CORS**: Currently configured permissively for development (needs restriction for production)
- **Authentication**: Token-based security with proper password hashing
- **File Access**: Local filesystem access with project-based organization

### Scalability Notes
- **Database**: SQLite suitable for small to medium teams; can be migrated to PostgreSQL for larger deployments
- **File Storage**: Local storage appropriate for internal use; can be extended to cloud storage if needed
- **Performance**: FastAPI's async capabilities provide good performance for typical engineering team sizes

## Deployment Instructions

### Local Deployment (Recommended)
1. Download or clone the project files
2. Install Python 3.7+ and pip
3. Install dependencies: `pip install fastapi sqlalchemy passlib[bcrypt] python-multipart uvicorn psycopg2-binary`
4. Run the server: `uvicorn main:app --host 0.0.0.0 --port 8000`
5. Access the application at `http://localhost:8000`
6. View API documentation at `http://localhost:8000/docs`

### Production Deployment
1. Set up PostgreSQL database and configure `DATABASE_URL` environment variable
2. Restrict CORS origins in main.py for security
3. Use a production ASGI server like Gunicorn with Uvicorn workers
4. Set up proper file storage with appropriate permissions
5. Configure backup procedures for database and uploaded files

### First-Time Setup
1. Register an admin user through the API
2. Create your first project
3. Upload project files and documentation
4. Set up user roles and permissions as needed

## Recent Changes (July 11, 2025)
- Fixed database compatibility issues for both SQLite and PostgreSQL
- Updated Pydantic models for modern compatibility
- Added comprehensive API documentation
- Implemented proper error handling and authentication
- Added file upload/download functionality
- Created complete project management workflow
- System is now ready for production deployment